import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-scope',
  templateUrl: './master-scope.component.html',
  styleUrls: ['./master-scope.component.css']
})
export class MasterScopeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
