import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterScopeComponent } from './master-scope.component';

describe('MasterScopeComponent', () => {
  let component: MasterScopeComponent;
  let fixture: ComponentFixture<MasterScopeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MasterScopeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterScopeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
