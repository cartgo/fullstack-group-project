import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { MasterScopeComponent } from './master-scope/master-scope.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { ProjectComponent } from './project/project.component';
import {PickListModule} from 'primeng/picklist';
import { AngularDualListBoxModule } from 'angular-dual-listbox';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    MasterScopeComponent,
    NavBarComponent,
    SideBarComponent,
    ProjectComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
,    AngularDualListBoxModule ,

    PickListModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
