export interface Project {
  project_code: number,
  project_name: string

   
}
