import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { Subscription } from "rxjs";
import { Component, OnInit, OnDestroy  } from '@angular/core';

import { map } from "rxjs/operators";
import { Router } from "@angular/router";
import{Project} from "./project.model"
// import {MysService} from "./project.service";

// import { environment } from "../../environments/environment";
// import { Post } from "./post.model";

// const BACKEND_URL = environment.apiUrl + "/posts/";

@Injectable({ providedIn: "root" })
export class ProjectService {
  private projects: Project[] = [];
//   private postsUpdated = new Subject<{ posts: Post[]; postCount: number }>();
//   newPost: Observable<Object>;
  constructor(public http:HttpClient, private router: Router) {}

  getData(postsPerPage?: number, currentPage?: number){
    let api = "https://jsonplaceholder.typicode.com/posts"; //////////////////////////////////////////
    return this.http.get<Project[]>(api).subscribe(data => this.projects = data);

  }


// //post
//   createPost(data) {
//     // const data = {
//     //   id: this.posts.length,
//     //   userId: 23,
//     //   title: 'My New Post',
//     //   body: 'Hello World!'
//     // } 
//     let api = "https://jsonplaceholder.typicode.com/posts";
//     // return this.http.post(api,data);
//      return this.http.post(api,data).subscribe(data => console.log(data));
//  }
 
 //delete
deletePost(id:number){
  let api = "https://jsonplaceholder.typicode.com/posts/";
  // return this.http.delete(api+id);
  return this.http.delete(api+id).subscribe(data => console.log(data));
  
}


//  thispost: any;
// updatePost( id: number,
//   userId?: number,
//   title?: string,
//   body?: string){
//    let api = "https://jsonplaceholder.typicode.com/posts/"+id;
//   return this.http
//       .put(api,this.thispost);
//     }
 
}
 

